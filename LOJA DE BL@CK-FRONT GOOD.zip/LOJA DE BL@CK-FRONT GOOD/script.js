
function showCategory(category) {
    // Limpa o conteúdo anterior
    document.getElementById('categoryProducts').innerHTML = '';

    // Define o título da categoria
    var categoryTitle = document.createElement('h1');
    categoryTitle.textContent = category;
    categoryTitle.classList.add('mb-4');
    document.getElementById('categoryProducts').appendChild(categoryTitle);

    // Cria a estrutura de produtos (substitua com os produtos reais da categoria)
    var productCarousel = document.createElement('div');
    productCarousel.classList.add('carousel', 'slide');
    productCarousel.setAttribute('data-bs-ride', 'carousel');
    var carouselInner = document.createElement('div');
    carouselInner.classList.add('carousel-inner');
    var carouselItem = document.createElement('div');
    carouselItem.classList.add('carousel-item', 'active');
    var row = document.createElement('div');
    row.classList.add('row');
    for (var i = 1; i <= 4; i++) {
      var col = document.createElement('div');
      col.classList.add('col-md-3', 'mb-4');
      var card = document.createElement('div');
      card.classList.add('card');
      var img = document.createElement('img');
      img.classList.add('card-img-top');
      img.src = 'ini1\imag\nutri.jpg';
      img.alt = 'Produto ' + i;
      var cardBody = document.createElement('div');
      cardBody.classList.add('card-body');
      var title = document.createElement('h5');
      title.classList.add('card-title');
      title.textContent = 'Produto ' + i;
      var description = document.createElement('p');
      description.classList.add('card-text');
      description.textContent = 'Descrição breve do Produto ' + i + '.';
      var price = document.createElement('p');
      price.classList.add('card-text');
      price.textContent = 'Preço: $15.00';
      var buyLink = document.createElement('a');
      buyLink.href = '#';
      buyLink.classList.add('btn', 'btn-primary');
      buyLink.textContent = 'Comprar';
      cardBody.appendChild(title);
      cardBody.appendChild(description);
      cardBody.appendChild(price);
      cardBody.appendChild(buyLink);
      card.appendChild(img);
      card.appendChild(cardBody);
      col.appendChild(card);
      row.appendChild(col);
    }
    carouselItem.appendChild(row);
    carouselInner.appendChild(carouselItem);
    productCarousel.appendChild(carouselInner);
    document.getElementById('categoryProducts').appendChild(productCarousel);
  }